package com.flight.api.flightsearch.service;

import com.flight.api.flightsearch.dto.Flight;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FlightSearchService {
    public List<Flight> getFlights(String origin, String destination) throws Exception;
}
