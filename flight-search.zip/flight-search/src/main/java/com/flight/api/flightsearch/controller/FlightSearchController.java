package com.flight.api.flightsearch.controller;

import com.flight.api.flightsearch.dto.Flight;
import com.flight.api.flightsearch.service.FlightSearchService;
import com.flight.api.flightsearch.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
public class FlightSearchController {

    @Autowired
    FlightSearchService flightSearchService;

    /**
     *
     * @param origin
     * @param destination
     * @return filtered flights on the basis of origin and destination
     */
    @GetMapping("/flights")
    public ResponseEntity<List<Flight>> getFlights(@RequestParam Optional<String> origin, @RequestParam Optional<String> destination){
        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<List<Flight>> responseEntity;
        try{
            List<Flight> flights = flightSearchService.getFlights(origin.orElse(Constants.INVALID_REQUEST_PARAMETERS), destination.orElse(Constants.INVALID_REQUEST_PARAMETERS));
            responseEntity = new ResponseEntity<>(flights,headers, HttpStatus.OK);
            return responseEntity;
        }catch(IOException e){
            responseEntity = new ResponseEntity<>(null,headers, HttpStatus.BAD_REQUEST);
        }catch (Exception ex){
            responseEntity = new ResponseEntity<>(null,headers, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }
}
