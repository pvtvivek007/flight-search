package com.flight.api.flightsearch.service.impl;

import com.flight.api.flightsearch.dto.Flight;
import com.flight.api.flightsearch.mapper.FlightMapper;
import com.flight.api.flightsearch.model.Flights;
import com.flight.api.flightsearch.repository.FlightSearchRepository;
import com.flight.api.flightsearch.service.FlightSearchService;
import com.flight.api.flightsearch.util.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class FlightSearchServiceImpl implements FlightSearchService {

    @Autowired
    FlightSearchRepository flightSearchRepository;

    @Autowired
    FlightMapper flightMapper;
    /**
     *
     * @param origin
     * @param destination
     * @return
     * @throws Exception
     */
    @Override
    public List<Flight> getFlights(String origin, String destination) throws Exception{
        if(origin.equals(Constants.INVALID_REQUEST_PARAMETERS) || destination.equals(Constants.INVALID_REQUEST_PARAMETERS)){
            throw new IOException(Constants.INVALID_REQUEST_PARAMETERS);
        }
        List<Flights> flights = new ArrayList<>();
        flightSearchRepository.findAll().forEach(flight -> flights.add(flight));
        List<Flights> filteredFlights = flights.stream().filter(f->f.getOrigin().equalsIgnoreCase(origin)).filter(fl->fl.getDestination().equalsIgnoreCase(destination)).collect(Collectors.toList());
        return flightMapper.getMappedFlightList(filteredFlights);
    }
}
