package com.flight.api.flightsearch.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class Flight implements Serializable {
    private String flightNumber;
    private String origin;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private String price;
}
