package com.flight.api.flightsearch.repository;

import com.flight.api.flightsearch.model.Flights;
import org.springframework.data.repository.CrudRepository;

public interface FlightSearchRepository extends CrudRepository<Flights, String> {
}
