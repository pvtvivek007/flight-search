package com.flight.api.flightsearch.mapper;

import com.flight.api.flightsearch.dto.Flight;
import com.flight.api.flightsearch.model.Flights;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class FlightMapper {

    public List<Flight> getMappedFlightList(List<Flights> sourceFlightList){
        if(sourceFlightList == null || sourceFlightList.size() < 1){
            return null;
        }
        List<Flight> flights = new ArrayList<>();
        sourceFlightList.forEach(f->flights.add(getMappedFlight(f)));
        return flights;
    }

    private Flight getMappedFlight(Flights flights){
        if(flights == null){
            return null;
        }
        Flight flight = new Flight();
        flight.setFlightNumber(flights.getFlightNumber());
        flight.setOrigin(flights.getOrigin());
        flight.setDestination(flights.getDestination());
        flight.setDepartureTime(flights.getDepartureTime());
        flight.setArrivalTime(flights.getArrivalTime());
        flight.setPrice(flights.getPrice());
        return flight;
    }
}
