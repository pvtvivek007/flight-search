package com.flight.api.flightsearch.util;

public class Constants {
    public static final String INVALID_REQUEST_PARAMETERS = "Invalid Request Parameters";
}
